class TestServiceUser:
    def test_add_user_successful(self):
        pass

    def test_add_user_exist(self):
        pass

    def test_add_user_null(self):
        pass

    def test_add_user_is_not_string(self):
        pass

    def test_remove_user_successful(self):
        pass

    def test_remove_user_not_exist(self):
        pass

    def test_remove_user_null(self):
        pass

    def test_remove_user_is_not_string(self):
        pass