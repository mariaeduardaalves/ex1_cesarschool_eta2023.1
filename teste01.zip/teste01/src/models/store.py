class Store:
    def __init__(self):
        self.bd = []
